﻿using System;
Console.WriteLine("Give me integers: ");
int[] nums = Console.ReadLine()
             .Split()
             .Select(int.Parse)
             .ToArray();
Queue<int> evenNumbers = new Queue<int>();
foreach (int n in nums)
{
    if (n % 2 == 0)
    {
        evenNumbers.Enqueue(n);
    }
}
Console.Write("The even numbers are: ");
int counter = evenNumbers.Count;
for (int i = 0; i < counter - 1; i++)
{
    Console.Write($"{evenNumbers.Dequeue()}, ");
}
Console.WriteLine(evenNumbers.Dequeue());
