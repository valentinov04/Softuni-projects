﻿Console.WriteLine("Write some numbers:");
int[] numbers = Console.ReadLine().Split().Select(int.Parse).ToArray();
Stack<int> stack = new Stack<int>();
foreach (int num in numbers)
{
    stack.Push(num);
}
Console.WriteLine("Write a command:");
string commands = Console.ReadLine();
string command = commands.Split()[0].ToLower();
while (command != "end")
{
    var tokens = commands.Split();
    if (command == "")
    {
        Console.WriteLine("Write a command:");
        commands = Console.ReadLine();
        command = commands.Split()[0].ToLower();
        continue;
    }

    if (command == "add")
    {
        int num1 = int.Parse(tokens[1]);
        int num2 = int.Parse(tokens[2]);
        stack.Push(num1);
        stack.Push(num2);
    }
    else if (command == "remove")
    {
        int count = int.Parse(tokens[1]);
        if (count > stack.Count)
        {
            Console.WriteLine("Write a command:");
            commands = Console.ReadLine();
            command = commands.Split()[0].ToLower();
            continue;
        }
        for (int i = 0; i < count; i++)
        {
            stack.Pop();
        }
    }
    Console.WriteLine("Write a command:");
    commands = Console.ReadLine();
    command = commands.Split()[0].ToLower();
}
int sum = stack.Sum();
Console.WriteLine($"Sum: {sum}");