﻿using System;

namespace StackCalculator
{
    class StackCalc
    {
        public static void Main()
        {
            /*
            10 - 3 - 2 - 1 + 3 - 2 = 5
            2 + 2 + 2 - 3 - 3 - 3 = -3
            */

            // Expression input. Expects a valid expression.
            Console.WriteLine("Write your expression:");
            string[] tokens = Console.ReadLine().Split().ToArray();

            // Push numbers and operators in a stack.
            Stack<string> s = new Stack<string>();
            for (int i = tokens.Length - 1; i >= 0; --i)
                s.Push(tokens[i]);

            // Calculate the result.
            int result = Int32.Parse(s.Pop());
            while (s.Count > 0)
            {

                /*// Print intermediate steps.
                Console.Write($"{result} ");
                foreach (var token in s)
                Console.Write(token + " ");
                Console.WriteLine();*/

                string op = s.Pop();
                int n = Int32.Parse(s.Pop());

                if (op == "+")
                    result += n;
                else
                    result -= n;
            }

            Console.WriteLine($"Result = {result}");
        }
    }

}

